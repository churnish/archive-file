var m = Object.defineProperty;
var S = Object.getOwnPropertyDescriptor;
var F = Object.getOwnPropertyNames;
var b = Object.prototype.hasOwnProperty;
var y = (p, c) => {
    for (var e in c) m(p, e, { get: c[e], enumerable: !0 });
  },
  C = (p, c, e, t) => {
    if ((c && typeof c == "object") || typeof c == "function")
      for (let s of F(c))
        !b.call(p, s) &&
          s !== e &&
          m(p, s, {
            get: () => c[s],
            enumerable: !(t = S(c, s)) || t.enumerable,
          });
    return p;
  };
var E = (p) => C(m({}, "__esModule", { value: !0 }), p);
var A = {};
y(A, { default: () => f });
module.exports = E(A);
var i = require("obsidian"),
  I = {
    showInFileMenu: !0,
    showInRibbon: !0,
    showInSearch: !0,
    showNotification: !0,
    archiveFolder: "",
    useTimestamps: !0,
    tagsToStrip: "",
    removeEmptyTags: !0,
  },
  f = class extends i.Plugin {
    async onload() {
      (await this.loadSettings(),
        this.addCommand({
          id: "archive-file",
          name: "Archive file",
          icon: "lucide-archive-restore",
          callback: () => this.archiveActiveFile(),
        }),
        this.settings.showInFileMenu &&
          this.registerEvent(
            this.app.workspace.on("file-menu", (e, t) => {
              t instanceof i.TFile &&
                e.addItem((s) => {
                  s.setTitle("Archive file")
                    .setIcon("lucide-archive-restore")
                    .setSection("action")
                    .onClick(() => this.archiveFiles([t]));
                });
            }),
          ),
        this.settings.showInFileMenu &&
          this.registerEvent(
            this.app.workspace.on("files-menu", (e, t) => {
              let s = t.filter((a) => a instanceof i.TFile);
              s.length !== 0 &&
                e.addItem((a) => {
                  a.setTitle(this.getMenuTitle(s.length))
                    .setIcon("lucide-archive-restore")
                    .setSection("action")
                    .onClick(() => this.archiveFiles(s));
                });
            }),
          ),
        this.settings.showInRibbon &&
          this.addRibbonIcon("lucide-archive-restore", "Archive file", () =>
            this.archiveActiveFile(),
          ),
        this.settings.showInSearch &&
          this.registerEvent(
            this.app.workspace.on("search:results-menu", (e, t) => {
              var a, l;
              let s = [];
              if (
                (l = (a = t.dom) == null ? void 0 : a.vChildren) != null &&
                l.children
              )
                for (let h of t.dom.vChildren.children)
                  h.file instanceof i.TFile && s.push(h.file);
              s.length !== 0 &&
                e.addItem((h) => {
                  h.setTitle(this.getMenuTitle(s.length))
                    .setIcon("lucide-archive-restore")
                    .setSection("action")
                    .onClick(() => this.archiveFiles(s));
                });
            }),
          ),
        this.addSettingTab(new w(this.app, this)));
    }
    archiveActiveFile() {
      let e = this.app.workspace.getActiveFile();
      e ? this.archiveFiles([e]) : new i.Notice("No active file");
    }
    getMenuTitle(e) {
      return e === 1 ? "Archive file" : `Archive ${e} files`;
    }
    async archiveFiles(e) {
      if (e.length === 0) return;
      if (!this.settings.archiveFolder) {
        new i.Notice("No archive folder set");
        return;
      }
      let t = (0, i.moment)(),
        s = this.settings.useTimestamps
          ? this.settings.archiveFolder.replace(/\{([^}]+)\}/g, (g, n) =>
              t.format(n),
            )
          : this.settings.archiveFolder;
      s = s.replace(/^\/+|\/+$/g, "");
      let a = this.settings.tagsToStrip
          ? this.settings.tagsToStrip
              .split(",")
              .map((g) => g.trim().replace(/^#/, "").toLowerCase())
              .filter(Boolean)
          : [],
        l = 0,
        h = 0;
      for (let g of e) {
        let n = await this.archiveFile(g, s, a);
        n === "moved" ? l++ : n === "failed" && h++;
      }
      this.settings.showNotification &&
        (e.length === 1 && h === 0
          ? new i.Notice("File archived")
          : l > 0 &&
            new i.Notice(l === 1 ? "1 file archived" : `${l} files archived`));
    }
    async archiveFile(e, t, s) {
      var h, g;
      let l =
        ((g = (h = e.parent) == null ? void 0 : h.path) != null ? g : "") !== t;
      try {
        if (l) {
          t &&
            !this.app.vault.getAbstractFileByPath(t) &&
            (await this.app.vault.createFolder(t));
          let n = e.name,
            v = 1,
            d = (u) => (t ? `${t}/${u}` : u);
          for (; this.app.vault.getAbstractFileByPath(d(n)); )
            ((n = e.extension
              ? `${e.basename} ${v}.${e.extension}`
              : `${e.basename} ${v}`),
              v++);
          await this.app.fileManager.renameFile(e, d(n));
        }
        if (s.length > 0 && e.extension === "md")
          try {
            await this.app.fileManager.processFrontMatter(e, (n) => {
              if (n.tags) {
                let d = (Array.isArray(n.tags) ? n.tags : [n.tags]).filter(
                  (u) => !s.includes(u.replace(/^#/, "").toLowerCase()),
                );
                d.length === 0
                  ? this.settings.removeEmptyTags
                    ? delete n.tags
                    : (n.tags = null)
                  : (n.tags = d);
              }
            });
          } catch (n) {
            console.error("Failed to strip tags:", n);
          }
        return l ? "moved" : "skipped";
      } catch (n) {
        return (console.error("Failed to archive:", n), "failed");
      }
    }
    async loadSettings() {
      this.settings = Object.assign({}, I, await this.loadData());
    }
    async saveSettings() {
      await this.saveData(this.settings);
    }
  },
  w = class extends i.PluginSettingTab {
    constructor(e, t) {
      super(e, t);
      this.plugin = t;
    }
    display() {
      let { containerEl: e } = this;
      (e.empty(),
        e.addClass("archive-file-settings"),
        new i.Setting(e)
          .setName("Archive folder")
          .setDesc("Destination folder for archived files")
          .addText((r) => {
            (r
              .setPlaceholder("Archive")
              .setValue(this.plugin.settings.archiveFolder)
              .onChange(async (o) => {
                ((this.plugin.settings.archiveFolder = o),
                  await this.plugin.saveSettings());
              }),
              new T(this.app, r.inputEl));
          }));
      let t = e.createDiv("archive-file-sub-settings"),
        a = new i.Setting(t)
          .setName("Resolve timestamps in folder path")
          .addToggle((r) =>
            r
              .setValue(this.plugin.settings.useTimestamps)
              .onChange(async (o) => {
                ((this.plugin.settings.useTimestamps = o),
                  await this.plugin.saveSettings());
              }),
          ).descEl,
        l = (0, i.moment)();
      (a.appendText("Convert date tokens in {braces} using "),
        a.createEl("a", {
          text: "Moment.js",
          href: "https://momentjs.com/docs/#/displaying/format/",
        }),
        a.appendText(
          ` format. E.g., {YYYY} \u2192 ${l.format("YYYY")}, {MM} \u2192 ${l.format("MM")}.`,
        ));
      let h = new i.Setting(e)
          .setName("Tags to strip")
          .setDesc(
            "Comma-separated list of tags to remove from properties when archiving",
          ),
        g = e.createDiv("archive-file-sub-settings");
      (this.plugin.settings.tagsToStrip || g.addClass("archive-file-hidden"),
        h.addText((r) =>
          r
            .setPlaceholder("Inbox, todo")
            .setValue(this.plugin.settings.tagsToStrip)
            .onChange(async (o) => {
              ((this.plugin.settings.tagsToStrip = o),
                await this.plugin.saveSettings(),
                g.toggleClass("archive-file-hidden", !o));
            }),
        ),
        new i.Setting(g)
          .setName("Remove empty tags property")
          .setDesc(
            "Delete the tags property from properties if all tags are stripped",
          )
          .addToggle((r) =>
            r
              .setValue(this.plugin.settings.removeEmptyTags)
              .onChange(async (o) => {
                ((this.plugin.settings.removeEmptyTags = o),
                  await this.plugin.saveSettings());
              }),
          ),
        new i.Setting(e)
          .setName("File context menu")
          .setDesc(
            "Show archive option when right-clicking files (reload required)",
          )
          .addToggle((r) =>
            r
              .setValue(this.plugin.settings.showInFileMenu)
              .onChange(async (o) => {
                ((this.plugin.settings.showInFileMenu = o),
                  await this.plugin.saveSettings());
              }),
          ),
        new i.Setting(e)
          .setName("Ribbon icon")
          .setDesc("Show archive icon in the ribbon (reload required)")
          .addToggle((r) =>
            r
              .setValue(this.plugin.settings.showInRibbon)
              .onChange(async (o) => {
                ((this.plugin.settings.showInRibbon = o),
                  await this.plugin.saveSettings());
              }),
          ),
        new i.Setting(e)
          .setName("Vault search menu")
          .setDesc(
            "Show archive option in vault search results context menu (reload required)",
          )
          .addToggle((r) =>
            r
              .setValue(this.plugin.settings.showInSearch)
              .onChange(async (o) => {
                ((this.plugin.settings.showInSearch = o),
                  await this.plugin.saveSettings());
              }),
          ),
        new i.Setting(e)
          .setName("Show notification")
          .setDesc("Show a notice after archiving files")
          .addToggle((r) =>
            r
              .setValue(this.plugin.settings.showNotification)
              .onChange(async (o) => {
                ((this.plugin.settings.showNotification = o),
                  await this.plugin.saveSettings());
              }),
          )
          .settingEl.addClass("archive-file-settings-last"));
      let d = e
        .createEl("div", { cls: "archive-file-feedback-container" })
        .createEl("button", { cls: "mod-cta archive-file-feedback-button" });
      d.addEventListener("click", () => {
        globalThis.open(
          "https://github.com/greetclammy/archive-file/issues",
          "_blank",
        );
      });
      let u = d.createEl("div");
      ((0, i.setIcon)(u, "message-square-reply"),
        d.appendText("Leave feedback"));
    }
  },
  T = class extends i.AbstractInputSuggest {
    constructor(e, t) {
      super(e, t);
      this.inputEl = t;
    }
    getSuggestions(e) {
      let t = this.app.vault
        .getAllLoadedFiles()
        .filter((a) => a instanceof i.TFolder);
      if (!e) return t.slice(0, 10);
      let s = e.toLowerCase();
      return t.filter((a) => a.path.toLowerCase().includes(s)).slice(0, 10);
    }
    renderSuggestion(e, t) {
      t.setText(e.path || "/");
    }
    selectSuggestion(e) {
      ((this.inputEl.value = e.path || "/"),
        this.inputEl.trigger("input"),
        this.close());
    }
  };
